===============================================================================
Kesepakatan Lisensi
===============================================================================

Kesepakatan lisensi untuk perangkat lunak ini (selanjutnya disebut sebagai
PERANGKAT LUNAK) dapat dijelaskan sebagai berikut.

1 Hak kekayaan intelektual dalam PERANGKAT LUNAK tetap dimiliki oleh
   Fuji Xerox Co. Ltd. (Selanjutnya disebut sebagai Fuji Xerox) demikian juga sebagai
   pemegang hak cipta aslinya.

2 PERANGKAT LUNAK hanya boleh digunakan dengan produk yang kompatibel dengan
   Fuji Xerox (selanjutnya disebut sebagai PRODUK KOMPATIBEL) di negara tempat
   PRODUK KOMPATIBEL tersebut dibeli.

3 Anda diminta mematuhi catatan dan pembatasan ini (selanjutnya disebut sebagai
   CATATAN DAN PEMBATASAN) yang dinyatakan oleh Fuji Xerox selama Anda
   menggunakan PERANGKAT LUNAK.

4 Anda tidak diizinkan untuk mengubah, memodifikasi, merekayasa balik,
   mendekompilasi atau membongkar seluruh atau sebagian PERANGKAT LUNAK
   untuk tujuan menganalisis PERANGKAT LUNAK.

5 Anda tidak diizinkan mendistribusikan PERANGKAT LUNAK kepada jaringan
   komunikasi, atau mentransfer, menjual, menyewakan atau melisensikan
   PERANGKAT LUNAK kepada pihak ketiga dengan menduplikasi PERANGKAT LUNAK
   pada media apa pun seperti floppy disk atau pita magnetik.

6 Fuji Xerox, Mitra Saluran Fuji Xerox, Dealer Resmi dan pemegang asli hak cipta
   PERANGKAT LUNAK tidak bertanggung jawab atas kehilangan atau kerusakan
   yang timbul akibat pencocokan perangkat keras atau program yang tidak
   ditentukan dalam CATATAN DAN PEMBATASAN PERANGKAT LUNAK,
   atau modifikasi pada PERANGKAT LUNAK.

7 Fuji Xerox, Mitra Saluran Fuji Xerox, Dealer Resmi dan pemegang asli hak
   cipta PERANGKAT LUNAK tidak bertanggung jawab atas garansi atau
   tanggung jawab apa pun sehubungan dengan PERANGKAT LUNAK.

===============================================================================
PCL 6 Print Driver Ver.6.12.4 Tambahan Informasi
===============================================================================

Dokumen ini memberikan informasi tentang  pada
item-item berikut:

1. Produk Perangkat Keras Target
2. Persyaratan
3. Komentar Umum
4. Keterbatasan
5. Perbarui Perangkat Lunak

---------------------------------------------------
1. Produk Perangkat Keras Target
---------------------------------------------------
FUJI XEROX ApeosPort-VII C7773
           ApeosPort-VII C6673
           ApeosPort-VII C5573
           ApeosPort-VII C4473
           ApeosPort-VII C3373
           ApeosPort-VII C3372
           ApeosPort-VII C2273
           DocuCentre-VII C7773
           DocuCentre-VII C6673
           DocuCentre-VII C5573
           DocuCentre-VII C4473
           DocuCentre-VII C3373
           DocuCentre-VII C3372
           DocuCentre-VII C2273

---------------------------------------------------
2. Persyaratan
---------------------------------------------------
Harap dicatat bahwa driver ini beroperasi pada komputer yang menjalankan
sistem operasi berikut ini.

  Microsoft(R) Windows Server(R) 2008 x64 Editions
  Microsoft(R) Windows(R) 7 x64 Editions
  Microsoft(R) Windows Server(R) 2008 R2
  Microsoft(R) Windows Server(R) 2012
  Microsoft(R) Windows(R) 8.1 x64 Editions
  Microsoft(R) Windows Server(R) 2012 R2
  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019

  Kunjungi situs web kami untuk memeriksa perangkat lunak
  terbaru dan sistem operasi yang didukung.

---------------------------------------------------
3. Komentar Umum
---------------------------------------------------
* Tutup semua aplikasi yang dijalankan sebelum menginstal driver cetak.

* Selalu nyalakan ulang komputer setelah menginstal versi driver cetak
  yang diperbarui.

* Jika Anda telah menghapus versi driver cetak yang lama, selalu nyalakan
  ulang komputer sebelum menginstal versi yang baru.

* Beberapa aplikasi menyediakan opsi pencetakan terkait dengan jumlah
  salinan dan salinan kolase. Selalu pilih opsi pencetakan dalam aplikasi
  kecuali instruksi menentukan lain. Gunakan dialog driver cetak untuk
  memilih opsi lanjutan seperti Cetak 2 Sisi, Set Contoh, atau opsi yang
  tidak tersedia dalam aplikasi.

* Selalu tutup dialog driver cetak dan/atau kotak dialog Cetak aplikasi
  sebelum Anda melakukan perubahan pada pengaturan standar
  driver cetak melalui Panel Kontrol.

* Jika output Offset Pekerjaan Anda tidak bekerja dengan baik pada salinan
  kolase, cobalah untuk membatalkan pilihan opsi [Kolase] dalam aplikasi
  dan menandai kotak centang [Kolase] dalam driver cetak.

* Jika Buku Telepon Faks tidak diinisialisasi atau dibuat oleh pengguna saat ini,
  dia mungkin tidak diberikan wewenang untuk mengaksesnya. Untuk akses
  yang tidak patut oleh pengguna, driver akan menampilkan pesan kesalahan
  yang menunjukkan bahwa default Buku Telepon Faks tidak dapat ditemukan
  atau Buku Telepon Faks yang ditentukan tidak dapat dikenali.
  Di sisi lain, jika pengguna ingin Buku Telepon Faksnya diakses oleh pengguna
  lain, ia harus menentukan grup dan pengguna yang aksesnya dia izinkan, dan
  harus memberi mereka setidaknya izin 'Ubah' ke file data
  Buku Telepon Faks.

* Pekerjaan faks harus dikirim secara terpisah ke setiap penerima yang
  ditentukan dengan kode-F, Kata Sandi atau atribut pengiriman aman.
  Jika tidak, printer selalu mengabaikan kode-F, Kata Sandi dan pengiriman
  aman atribut saat mengirim pekerjaan faks ke beberapa penerima. Pekerjaan
  yang ditransmisikan selalu dicetak langsung di semua tujuan yang ditentukan.

* Untuk pemasangan melalui jaringan, jika Anda mengklik kanan
  pada folder [Printer], buka [Jalankan sebagai administrator] dari menu dan pilih
  [Tambah printer ...], ikon printer mungkin tidak dihasilkan.

* Penggantian nama Ikon Printer harus mematuhi konvensi penamaan file OS.
  Penggunaan Simbol atau karakter khusus dapat menyebabkan kesalahan
  penggantian nama atau perilaku driver cetak yang tidak terduga.

* Sebelum menginstal driver cetak di lingkungan cluster Windows, Anda perlu
  menginstalnya pada setiap node di cluster.

---------------------------------------------------
4. Keterbatasan
---------------------------------------------------
* Pembatasan pada Driver Dukungan Paket-Sadar
  - Driver bukan Driver Bersertifikat Microsoft WHQL.
  Untuk kasus di atas di lingkungan Server-Client, ketika driver printer
  ditambahkan atau ditingkatkan di sisi Server, dialog yang meminta
  pengguna untuk menginstal driver printer atau dialog Kontrol Akun
  Pengguna dapat ditampilkan di sisi Klien.

* Tentang [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]
  Untuk hasil cetak yang konsisten dengan pengaturan warna yang ditentukan oleh
  UI aplikasi, atur [Cetak Menggunakan Warna Tertentu Aplikasi] dan [Prioritaskan
  Warna Tertentu Aplikasi saat Warna Output Hitam Putih] ke [On].

  Berikut ini menjelaskan hubungan antara pengaturan driver printer ([Warna Output],
  [Cetak Menggunakan Warna Tertentu Aplikasi], dan [Prioritaskan Warna Tertentu
  Aplikasi saat Warna Output Hitam Putih]), dan output cetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [Off]
    Warna Output yang ditentukan oleh aplikasi akan diabaikan, dan pengaturan
    [Warna Output] UI driver akan digunakan untuk mencetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [On]
    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [On]
      Warna Output yang ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [Off]
      Jika pengaturan [Warna Output] driver UI adalah [Warna], Warna Output yang
      ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika pengaturan [Warna Output] driver UI adalah [Hitam Putih], Warna Output
      ditentukan oleh aplikasi akan diabaikan, dan hasil cetak akan menjadi hitam putih.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

* Pada Microsoft Windows 7 atau versi yang lebih baru pilih printer dari
  folder [Perangkat dan Printer]. Pilih Properti printer dan klik tombol [Ubah
  Opsi Berbagi] pada tab [Berbagi].
  Kemudian, tentukan Ukuran Kertas Kustom.

* Resolusi default driver ini adalah% DefaultResolution%. (Ditunjukkan Otomatis.)
  Saat mengeluarkan melalui driver, resolusi yang berbeda dari salah satu driver ini,
  kesalahan seperti berikut dapat diamati tergantung pada spesifikasi atau batasan
  aplikasi.
  - Tata letak dokumen dicetak diubah.
  - Hasil cetak dari garis atau pola diubah.
  - Garis yang tidak perlu dicetak pada output.
  - Garis yang diperlukan tidak dicetak pada output.

  Dalam kasus seperti itu, status dapat ditingkatkan dengan mengubah
  pengaturan [Resolusi] pada tab [Tingkat Lanjut].

* Ketika pola atau diagram yang dicetak berbeda dari apa yang Anda lihat di
  layar, mengubah pengaturan berikut dapat mengurangi masalah.
  - Ubah pengaturan [Kualitas Gambar] pada tab [Opsi Warna].
  - Ubah pengaturan [Tipe Gambar] dan [Koreksi Otomatis Gambar] pada
    Tab [Opsi Warna].
  - Atur [Pemrosesan Gambar Kecepatan Tinggi] pada tab [Tingkat Lanjut] ke [Off].
  - Atur [Gambar pola dengan garis-garis halus sesuai resolusi] pada
    tab [Tingkat Lanjut] ke[On].
  - Ubah pengaturan [Resolusi] dalam grup [Opsi Gambar] pada
    tab [Tingkat Lanjut].
  - Ubah pengaturan [Cetak Halftone] dalam grup [Opsi Gambar] pada
    tab [Tingkat Lanjut].

* Pemisah Kosong
  Jika Anda mengatur [Spool EMF] ke [Aktif] atau menentukan Header, Footer,
  dan Watermark, dan melakukan [Cetak 2 Sisi] dengan dokumen halaman ganjil,
  halaman kosong dapat dimasukkan pada halaman terakhir tergantung pada
  aplikasi atau OS.

* Tata letak cetak mungkin berubah ketika Anda mengubah [Kualitas Gambar]
  di tab [Opsi Warna].

* Tergantung pada aplikasinya, jika resolusi driver tinggi, maka ukuran data
  cetak mungkin menjadi sangat besar dan pencetakan tidak dapat dilakukan
  dengan benar. Ketika ini terjadi, tentukan pengaturan berikut:
  - Tentukan [Resolusi] di grup [Opsi Gambar] di tab [Tingkat Lanjut]
    ke [300 dpi] atau [200 dpi].

* Untuk beberapa aplikasi, jika gambar yang ditempel dicetak pada resolusi tinggi,
  data cetak meluas dan dapat mengakibatkan kecepatan cetak yang sangat lambat.
  Ukuran data cetak dari output dapat ditingkatkan dengan mengubah pengaturan
  grup [Opsi Gambar] yang berikut ini pada tab [Tingkat Lanjut].
  - Tentukan [Kompresi Gambar] ke [Standar] atau [Foto] atau [Resolusi] untuk
    [300 dpi] atau [200 dpi].

* Saat mencetak dari aplikasi QuarkXPress 6.1E, jika pengaturan [Kualitas Gambar]
  adalah [Resolusi Tinggi] dan resolusi driver adalah [1200 dpi], dokumen dapat
  dicetak sebagai halaman kosong. Masalah ini dapat dihindari dengan mengubah
  resolusi driver ke [Otomatis].

* Saat melakukan pekerjaan cetak dengan menetapkan Sumber Kertas sebagai
  Otomatis, pastikan untuk mengatur Ukuran Kertas dalam aplikasi ke Ukuran
  Kertas yang didukung driver untuk mengaktifkan fitur pengumpanan kertas otomatis.

* Saat menggunakan fitur Hamparkan Formulir, gunakan data formulir dengan
  Ukuran Kertas yang sama, Resolusi, dan Pengaturan Gambar seperti pada
  dokumen yang ingin Anda cetak. Jika pengaturan ini berbeda antara data
  formulir dan halaman tempat data formulir dimasukkan, hasil cetak yang
  diharapkan mungkin tidak diperoleh.

* Saat menggunakan Hamparkan Formulir, karena beberapa aplikasi mengecat
  latar belakang dengan warna putih untuk mencetak, formulir dengan overlay
  mungkin disembunyikan. Aplikasi tersebut termasuk Internet Explorer dan WordPad.

* Hasil cetak mungkin tumpang tindih jika Halaman Per Lembar (N-Up) dan
  Margin [Standar] dipilih saat mencetak dokumen yang telah melebihi area
  cetak driver cetak. Ketika ini terjadi, pilih [Tidak Ada] dari grup tombol radio
  [Margin] pada tab [Opsi Gambar].

* Saat Anda membatalkan pekerjaan faks yang sedang berlangsung dari driver,
  aplikasi mungkin menampilkan kotak dialog peringatan. Ini mungkin
  menunjukkan pesan kesalahan printer,meskipun tidak ada kesalahan pada
  printer. Dalam hal ini, abaikan pesan peringatan itu dan lanjutkan operasi.

* Untuk menggunakan fitur [Simpan di Folder Jarak Jauh], Anda harus mendapatkan
  nomor folder dan kode sandi penerima yang sebelumnya sudah terdaftar.
  Lihat panduan administrator mesin tentang cara membuat folder.

* Bergantung pada aplikasi yang digunakan oleh pelanggan, halaman kosong
  untuk halaman penyesuaian akan otomatis dimasukkan sesuai kondisi misalnya
  jumlah salinan yang ditentukan saat mengeluarkan cetakan 2 sisi.
  Dalam hal ini, sisipan kosong akan dimasukkan oleh aplikasi.
  Kinerja dapat ditingkatkan dengan mengubah pengaturan di bawah ini.
  - Periksa [Lompati Halaman Kosong] pada tab [Tingkat Lanjut].

* Bahkan dengan [Lompati Halaman Kosong] dipilih, halaman kosong mungkin
  masih dicetak dalam situasi berikut.
  - Halaman ini hanya berisi umpan baris.
  - Halaman ini hanya berisi spasi.
  - Halaman ini hanya berisi feed dan spasi baris.
  - Instruksi gambar latar belakang putih dikirim dari aplikasi.

* Dengan Microsoft Word, bahkan jika [Lompati Halaman Kosong] ditentukan,
  saat kosong halaman disertakan dalam dokumen, mungkin itu output.

* Untuk pelanggan yang menggunakan Microsoft Windows Server 2008 Cluster Environment

  <1> Untuk menentukan ukuran kertas khusus di lingkungan cluster, tentukan
      pengaturan yang umum untuk semua node fisik di lingkungan cluster.

  <2> Ketika kotak dialog [Cari Printer] muncul dengan menekan tombol
      [Dapatkan Informasi dari Printer], masukkan alamat jaringan printer

  <3> Menghapus driver di lingkungan cluster
      Setelah driver di server virtual dihapus, hapus driver
      di semua node siaga.
      ** Menghapus driver dari node siaga
        (1) Ubah node siaga ke node aktif.
        (2) Instal printer di server virtual.
        (3) Hapus driver dari server virtual.

  <4> Menghapus driver
      Setelah ikon printer dihapus, hapus driver dari [Properti
      Server]. Lalu, nyalakan ulang komputer.

* Tombol [Batal] pada Dialog [Pengaturan Detail Pengguna]
  Untuk beberapa aplikasi, jika dialog [Masukkan Detail Pengguna] dibatalkan saat
  mencetak dengan pengaturan [Minta Pengguna untuk Masuk saat Mengirim pekerjaan]
  pada dialog [Pengaturan Detail Pengguna], dialog peringatan dapat ditampilkan.
  Dialog peringatan ini dapat mengindikasikan kesalahan printer, tetapi
  sebenarnya printer tidak ada masalah.

  Dalam hal ini, abaikan peringatan dan lanjutkan.

* Ketika [Spool EMF] dari tab [Tingkat Lanjut] diatur ke [Nonaktif], beberapa
  dokumen dengan struktur yang kompleks mungkin memiliki masalah seperti gambar
  output terdistorsi dan kegagalan output.

* Untuk mengubah pengaturan Ukuran Kertas Khusus, Anda memerlukan hak
  akses Administrator. Pada Windows Server 2008, pilih printer dari folder printer,
  klik kanan untuk membuka [Jalankan sebagai Administrator] dan pilih [Properti].
  Setelah mengklik [Lanjutkan] di [Kontrol Akun Pengguna], anda dapat mengubah
  pengaturan dari Properti.

  Ketika Ukuran Kertas Khusus sama dengan ukuran kertas standar ditentukan
  dalam Kertas Ukuran, pekerjaan cetak dapat dilakukan seolah-olah ukuran
  kertas [standar] ditentukan.
  Untuk output sebagai Ukuran Kertas Khusus, tentukan Ukuran Kertas Khusus
  dalam Ukuran Output.

* Dengan pengaturan default Firewall, data dalam siaran lintas-subnet tidak
  dapat  diambil.
  Untuk pengambilan data lintas-subnet, harap jangan gunakan siaran dan
  tentukan alamat langsung.

* Ada batasan fitur di bawah ini pada pelaksanaan cetak Faks di
  Mode Terlindungi dari Microsoft Internet Explorer.
  - Pesan peringatan dapat ditampilkan segera setelah pelaksanaan cetak Faks.
  - Lokasi untuk penyimpanan Buku Telepon Faks bukan Folder Publik, yang
    biasanya digunakan untuk penyimpanan tetapi folder seperti Folder pribadi,
    yang bisa digunakan untuk pembuatan file. Oleh karena itu, isi Buku Telepon
    Faks berbeda dari yang teregistrasi dengan aplikasi lain.
  - Fitur Impor Ke Daftar Buku Telepon Faks tidak berfungsi.

* Ada batasan dalam membuat file dari Microsoft Internet Explorer.
  Anda tidak dapat menyimpan file data formulir di folder yang ditentukan
  sebagai default di [Buat / Daftar Formulir]. Ubah folder menjadi yang bisa
  digunakan untuk membuat file (seperti "Folder Dokumen") sebelum
  membuat/mendaftar formulir file data.

* Fungsi-fungsi berikut dibatasi dengan penggunaan Microsoft Internet Explorer
  dalam Mode Terlindungi.
  - Item pengaturan untuk [Tipe Pekerjaan] ([Cetak Aman] / [Set Contoh] /
    [Cetak Tertunda] / [Simpan di Folder Jarak Jauh]) tidak dapat diedit.
  - Fungsi [Pengaturan Tersimpan], [Simpan] dan [Edit] dinonaktifkan.
  - Fungsi [Watermark], [Baru], [Edit] dan [Hapus] dinonaktifkan.
  - Pengaturan [Beri Tahukan Selesainya Pekerjaan Melalui Email] tidak dapat diubah.
  Untuk mengubah pengaturan fungsi-fungsi ini, buka pengaturan default
  dokumen dari Folder Printer.

* Catatan dan batasan tentang lingkungan server-klien
- Masalah Lingkungan Server-Klien (1)
  Jika printer sedang digunakan sebagai printer bersama dan operasi server
  sistem sedang ditingkatkan, pesan yang menunjukkan bahwa driver harus
  diperbarui dapat muncul pada klien, menyebabkan pencetakan gagal.
  Dalam hal ini, driver cetak harus diinstal ulang pada klien supaya dapat
  mencetak lagi.

- Masalah Lingkungan Server-Klien (2)
  Di lingkungan Server-Client, setelah driver cetak ditambahkan atau
  ditingkatkan di sisi Server, pencetakan mungkin tidak dilakukan dengan
  pesan yang ditampilkan membutuhkan peningkatan driver cetak di sisi Klien.
  Masalah ini dapat dihindari dengan pengaturan di bawah ini.

  < Ubah Pengaturan Kebijakan Grup pada PC Klien >
  1. Masuk sebagai Administrator pada PC Klien.
  2. Buka perintah prompt dan lakukan "gpedit.msc". Untuk membuka [Editor
     Kebijakan Grup Lokal].
  3. Buka pohon di sebelah kiri dengan urutan berikut ini.
     [Konfigurasi Pengguna]
     [Templat Administratif]
     [Panel Kontrol]
     [Printer]
  4. Klik dua kali [Tunjuk dan Cetak Batasan] di panel kanan.
  5. Klik tombol radio [Nonaktif].
  6. Klik [OK] untuk menutup jendela.
  7. Tutup [Editor Kebijakan Grup Lokal].

* Batasan pada pencetakan dengan pengaturan Staple dan Berlubang
  secara bersamaan waktunya
  Staple dan Berlubang mungkin tidak berfungsi saat 1 Staple dan Berlubang
  sedang ditentukan secara bersamaan untuk beberapa ukuran kertas.

* Pengaturan Warna Output dari Aplikasi
  Untuk mencetak warna dari Aplikasi Windows Store, buka [Peranti dan Pencetak]
  dari Windows Desktop, klik kanan pada printer Anda untuk memilih [Preferensi
  Pencetakan] dan kemudian konfirmasikan bahwa [Warna Output] pada tab
  [Kertas/Output] pada dialog [Preferensi Pencetakan] diatur ke [Warna].
  Jika pengaturan [Warna Output] pada tab [Kertas/Output] pada dialog [Preferensi
  Pencetakan] tetap [Hitam Putih], output akan berwarna hitam dan putih bahkan jika
  Anda menentukan Mode Berwarna ke [Warna] pada layar pengaturan pencetakan
  ditampilkan setelah Anda memilih printer dari pesona perangkat.

* Keterbatasan pada Adobe Acrobat / Reader
  Saat Anda menentukan [2] atau lebih banyak halaman untuk [Salinan] pada dialog
  [Cetak] dari Adobe Acrobat/Reader, Faks mungkin tidak dikirim secara normal.

* Microsoft Outlook
  Saat mencetak Jadwal, bagian-bagian yang akan dicetak berwarna mungkin
  tampak dicetak dalam warna hitam dan putih dengan warna yang hilang.
  Jika toner warna digunakan untuk membuatnya tampak seperti abu-abu,
  pengukur akan menghitung pekerjaan itu sebagai pencetakan berwarna.
 
  Dalam kasus seperti itu, masalahnya dapat dihindari dengan metode berikut.
  1. Tutup Outlook.
  2. Klik kanan ikon printer di [Peranti dan Pencetak], dan buka [Mencetak
     preferensi].
  3. Klik tombol [OK] untuk menutup [Preferensi pencetakan].

  Dalam hal menggunakan ikon printer bersama, pengguna baru printer
  bersama dapat menghindari masalah dengan metode berikut. (Hanya
  administrator yang diizinkan untuk melakukan.)
  1. Klik kanan ikon printer di [Peranti dan Pencetak] dan buka [Properti
     printer].
  2. Buka tab [Tingkat Lanjut], lalu buka [Default Pencetakan].
  3. Klik tombol [OK] untuk menutup [Default Pencetakan].
  4. Tutup [Properti printer].

* Batasan pada pencetakan dengan pengaturan [Amplop] untuk [Tipe Kertas]
  Saat mencetak dengan pengaturan [Amplop] untuk [Tipe Kertas] atau [Tipe],
  pekerjaan cetak mungkin tidak dilakukan dengan benar.
  Untuk mencetak pada kertas jenis amplop, buka kotak dialog [Pemilihan
  Kertas Tingkat Lanjut], atur [Baki Kertas] ke [Baki 5 (Bypass)] lalu atur
  [Tipe Kertas Bypass] ke [Amplop].

* Anotasi dan Watermark tidak boleh dicetak bahkan jika [Anotasi] dan
  [Watermark] telah ditentukan.
  Untuk membuatnya berfungsi, atur [Spool EMF] ke [Aktif] di tab [Tingkat Lanjut].

---------------------------------------------------
5. Perbarui Perangkat Lunak
---------------------------------------------------
    Perangkat lunak terkini tersedia di situs web kami.

        https://www.fujixerox.com/

    Biaya komunikasi menjadi tanggungan pelanggan.

-------------------------------------------------------------------------------
Microsoft, Windows, Windows Server, Word, Excel, PowerPoint, Internet Explorer
dan Visio adalah merek dagang teregistrasi atau merek dagang milik Microsoft
Corporation di Amerika Serikat dan/atau negara lainnya.

Adobe, Acrobat, dan Reader adalah merek dagang terdaftar atau merek dagang
teregistrasi atau merek dagang milik Adobe Systems Incorporated di Amerika
Serikat dan/atau negara-negara lain.

CentreWare adalah merek dagang teregistrasi milik Xerox Corporation.

Nama perusahaan dan nama produk lain adalah merek dagang atau merek
dagang teregistrasi milik perusahaan-perusahaan terkait.

libjpeg 6b
----------
This software is based in part on the work of the Independent JPEG Group.

(C) Fuji Xerox Co., Ltd. 2018-2020
